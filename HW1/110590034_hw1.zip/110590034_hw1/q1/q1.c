#include <stdio.h>

int main() {
    printf("n = %d\n", 42);
    return 0;
}