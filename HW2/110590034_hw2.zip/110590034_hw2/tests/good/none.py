def foo():
    x = 1
print(foo())
print(foo() == foo())
print(foo() != foo())
