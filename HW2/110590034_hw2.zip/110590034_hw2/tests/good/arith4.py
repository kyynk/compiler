print(19 % 4)
