print("foo")
