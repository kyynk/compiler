print(len(list(range(7))))

